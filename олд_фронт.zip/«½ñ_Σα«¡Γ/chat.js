// search listener and handler

const search_input = document.querySelector('.menu-search')

search_input.addEventListener("edit", function (arg) {
	alert("change")
})
